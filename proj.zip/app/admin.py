from django.contrib import admin

from app.models import Journey, Goal

# Register your models here.
admin.site.register(Journey)
admin.site.register(Goal)